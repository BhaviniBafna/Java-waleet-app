package com.bhavini.walletapp.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity

public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;
    @Size(min = 2,max = 30)
    private String accountNumber;
    private String operation;
    private Double transactionAmt;
    @Min(1)
    @NotNull(message = "amount can not be null")
    private Double currentBalance;
    @JsonFormat(pattern="yyyy-mm-dd")
    private Date transactionDate;
}
