package com.bhavini.walletapp.controller;

import com.bhavini.walletapp.dto.Operations;
import com.bhavini.walletapp.entity.Transaction;
import com.bhavini.walletapp.entity.Wallet;
import com.bhavini.walletapp.service.TransactionService;
import com.bhavini.walletapp.service.ValidationErrorService;
import com.bhavini.walletapp.service.WalletService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Date;

@RestController
@RequestMapping("/wallet")
public class WalletController {
    @Autowired
    private WalletService walletService;
    @Autowired
    private TransactionService transactionService;
    @Autowired
    private ValidationErrorService validationService;

    @GetMapping("/all")
    public ResponseEntity<?> getAll() {
        return new ResponseEntity<>(walletService.getAll(), HttpStatus.OK);
    }

    @GetMapping("/{accountNum}")
    public ResponseEntity<?> getById(@PathVariable String accountNum) {
        return new ResponseEntity<>(walletService.getByAccountNumber(accountNum), HttpStatus.OK);
    }

    @PostMapping("/create")
    public ResponseEntity<?> create(@Valid @RequestBody Wallet wallet, BindingResult result) {
        ResponseEntity errors = validationService.validate(result);
        if (errors != null) return errors;
        Wallet walletSaved = walletService.createOrUpdate(wallet);
        return new ResponseEntity<Wallet>(walletSaved, HttpStatus.CREATED);
    }

    @PutMapping("/operation/{accountNumber}")
    public ResponseEntity<?> update(@PathVariable String accountNumber, @Valid @RequestBody Operations operations, BindingResult result) {
        ResponseEntity errors = validationService.validate(result);
        if (errors != null) return errors;
        if (accountNumber != null) {
            Double totalAmt;
            Wallet walletSaved = walletService.getByAccountNumber(accountNumber);
            Transaction transaction = new Transaction();
            transaction.setAccountNumber(accountNumber);
            totalAmt = walletSaved.getCurrentBalance() - operations.getAmount();
            if (operations.getAction().equalsIgnoreCase("debit")) {
                totalAmt = walletSaved.getCurrentBalance() - operations.getAmount();
                transaction.setCurrentBalance(totalAmt);
                transaction.setOperation("debit");
                transaction.setTransactionAmt(operations.getAmount());
            } else {
                totalAmt = walletSaved.getCurrentBalance() + operations.getAmount();
                transaction.setCurrentBalance(totalAmt);
                transaction.setOperation("credit");
                transaction.setTransactionAmt(operations.getAmount());
            }
            transaction.setTransactionDate(new Date());
            transactionService.createOrUpdate(transaction);
            walletSaved.setCurrentBalance(totalAmt);
            walletService.createOrUpdate(walletSaved);
            return new ResponseEntity<Wallet>(walletSaved, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }

    @DeleteMapping("/{accountNumber}")
    public ResponseEntity<?> delete(@PathVariable String accountNumber) {
        walletService.delete(accountNumber);
        transactionService.delete(accountNumber);
        return new ResponseEntity(HttpStatus.OK);
    }
}
