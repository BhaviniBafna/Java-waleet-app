package com.bhavini.walletapp.service;

import com.bhavini.walletapp.entity.Transaction;
import com.bhavini.walletapp.exception.WalletException;
import com.bhavini.walletapp.repository.TransactionRepository;
import com.bhavini.walletapp.repository.WalletRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TransactionService {
    @Autowired
    private TransactionRepository transactionRepository;
    @Autowired
    private WalletRepository walletRepository;
    public List<Transaction> getAll() {
        List<Transaction> transaction = transactionRepository.findAll();
        if (transaction!=null) {
            return transaction;
        }
        return null;
    }
    public List<Transaction> getById(String accountNumber){
        List<Transaction> transaction = transactionRepository.findByAccountNumber(accountNumber);
        if(transaction!=null){
            return transaction;
        }
        return null;
    }
    public Transaction createOrUpdate(Transaction transaction){
        transaction = transactionRepository.save(transaction);;
        return transaction;
    }
    public boolean delete(String accountNumber){
        List<Transaction> transaction = transactionRepository.findByAccountNumber(accountNumber);
        if (transaction!= null) {
            transactionRepository.deleteAll(transaction);
        }
        throw new WalletException("Transaction with "+accountNumber+" does not exists!");
    }
}
