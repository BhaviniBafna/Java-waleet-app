package com.bhavini.walletapp.service;

import com.bhavini.walletapp.repository.WalletRepository;
import com.bhavini.walletapp.entity.Wallet;
import com.bhavini.walletapp.exception.WalletException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class WalletService {
    @Autowired
    private WalletRepository walletRepository;
    public List<Wallet> getAll(){
        return walletRepository.findAll();
    }
    public Wallet getByAccountNumber(String accountNumber){
        Optional<Wallet> wallet = walletRepository.findByAccountNumber(accountNumber);
        if(wallet.isPresent()){
            return wallet.get();
        }
        throw new WalletException("Wallet with "+accountNumber+" does not exists!");
    }
    public Wallet createOrUpdate(Wallet wallet){
        walletRepository.save(wallet);
        return wallet;
    }
    public boolean delete(String accountNumber){
        Optional<Wallet> wallet = walletRepository.findByAccountNumber(accountNumber);
        if(wallet.isPresent()){
            walletRepository.delete(wallet.get());
            return true;
        }
        throw new WalletException("Wallet with "+ accountNumber +" does not exists!");
    }
}
