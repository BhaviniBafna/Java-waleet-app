package com.bhavini.walletapp.controller;

import com.bhavini.walletapp.service.TransactionService;
import com.bhavini.walletapp.service.ValidationErrorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/transaction")
public class TransactionController {
    @Autowired
    private TransactionService transactionService;
    @Autowired
    private ValidationErrorService validationService;
    @GetMapping("/all")
    public ResponseEntity<?> getAll(){
        return new ResponseEntity<>(transactionService.getAll(), HttpStatus.OK);
    }

    @GetMapping("/{accountNumber}")
    public ResponseEntity<?> getById(@PathVariable String accountNumber){

        return new ResponseEntity<>(transactionService.getById(accountNumber),HttpStatus.OK);
    }


    @DeleteMapping("/{accountNumber}")
    public ResponseEntity<?> delete(@PathVariable String accountNumber){
        transactionService.delete(accountNumber);
        return new ResponseEntity(HttpStatus.OK);
    }
}
